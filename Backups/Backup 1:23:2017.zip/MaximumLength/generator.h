#ifndef __GENERATOR_H__
#define __GENERATOR_H__

#define ML_BITS 5
#include <stdlib.h>

// "generate pseudo maximum length sequence"
void generate_ml_sequence(size_t * len, bool ** ret_seq);

#endif
